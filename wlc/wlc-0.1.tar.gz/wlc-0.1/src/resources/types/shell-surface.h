#ifndef _WLC_SHELL_SURFACE_H_
#define _WLC_SHELL_SURFACE_H_

#include <wayland-server-protocol.h>

const struct wl_shell_surface_interface wl_shell_surface_implementation;

#endif /* _WLC_SHELL_SURFACE_H_ */
