#ifndef _WLC_X11_H_
#define _WLC_X11_H_

#include <stdbool.h>

struct wlc_backend;

bool wlc_x11(struct wlc_backend *backend);

#endif /* _WLC_X11_H_ */
