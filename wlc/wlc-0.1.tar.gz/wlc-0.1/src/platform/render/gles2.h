#ifndef _WLC_GLES2_H_
#define _WLC_GLES2_H_

struct wlc_render_api;

void* wlc_gles2(struct wlc_render_api *api);

#endif /* _WLC_GLES2_H_ */
